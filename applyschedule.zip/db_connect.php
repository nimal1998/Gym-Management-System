<?php 

$conn= new mysqli('localhost','root','Q)=2[bXo01-e{AZ!','gym_db')or die("Could not connect to mysql".mysqli_error($con));
