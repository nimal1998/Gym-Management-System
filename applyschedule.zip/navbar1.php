<style>
	.collapse a{
		text-indent:10px;
	}
	nav#sidebar{
		background: url(assets/uploads/<?php echo $_SESSION['system']['cover_img'] ?>) !important
	}
</style>
<!-- navbar.php home members packages okk kanikunne -->
<nav id="sidebar" class='mx-lt-5 bg-dark' >
		<br><br>


			<div class="sidebar-list">
			<a href="user.php" class="nav-item nav-home1"><s1pan class='icon-field'><i class="fa fa-user"></i></span> Home</a>
		<a href="userpackages.php" class="nav-item nav-home"><span class='icon-field'><i class="fa fa-home"></i></span>Packages</a>
		</div>
		<a href="userschedule.php" class="nav-item nav-schedule"><span class='icon-field'><i class="fa fa-calendar-day"></i></span> Schedules</a>


</nav>
<script>

</script>
